#ifndef LISTBST_H
#define LISTBST_H

#include "BST.hpp"
#include <iostream>
#include <stdexcept>
using namespace std;

/**
 * Binary Search Tree implementation using linked list structure
 * 
 * @tparam Key - The type of keys stored in the BST
 * @tparam Value - The type of values associated with keys
 */
template <typename Key, typename Value>
class ListBST : public BST<Key, Value> {
private:
    /**
     * Node class for the binary search tree
     */
    class Node {
    public:
        Key key;
        Value value;
        Node* left;
        Node* right;
        
        Node(Key k, Value v) : key(k), value(v), left(nullptr), right(nullptr) {}
    };
    
    Node* root;
    size_t node_count;
    
    // TODO: Implement private helper functions as needed
    // Start your private helper functions here

    // PRIVATE FUNCTION TO DELETE POINTERS  
    void destructingFunc(Node* root){
         if(root==NULL)return;
         destructingFunc(root->left);
         destructingFunc(root->right);
         delete root;
    }
    
    //PRIVATE FUNCTION TO INSERT A VALUE TO BST
    Node* buildBST(Node* root,Key key,Value value){
        if(root==NULL){
            
            root=new Node(key,value);
            return root;
        }

        else if(key > root->key){
            root->right=buildBST(root->right,key,value);
        }
        else{
            root->left=buildBST(root->left,key,value);
        }
        return root;

    }

    // GETTING MINIMUM VALUE

    Node* Minimum(Node* root)const{
        Node* temp=root;
        while(temp->left){
            temp=temp->left;
        }
        return temp;
    }

    // FOR GETTING VALUE ASSOCIATED TO KEY
    Value getValue(Node* root,Key key)const{
        Node* temp=root;
        
        while(temp){
            if(temp->key==key){
                return temp->value;
            }
            else if(key > temp->key){
                temp=temp->right;
            }
            else {
                temp=temp->left;
            }
        }
        throw runtime_error("value not found");
        
    }

    //DELETING A VALUE FROM BST

    Node* deleteNode(Node* root,Key key,bool &flag){
        if(root==NULL){
            return NULL;
        }
        if(root->key==key){
            flag=true;
            //for leaf node
            if(root->left==NULL and root->right==NULL){
                delete root;
                return NULL;
            }

            // for one left child
            else if(root->left and root->right==NULL){
                Node* temp=root->left;
                delete root;
                return temp;
            }

            //for one right child
            else if(root->left==NULL and root->right){
                Node* temp=root->right;
                delete root;
                return temp;
            }

            // for both children
            else{
                Node* mini=Minimum(root->right);
                root->key=mini->key;
                root->value=mini->value;
                root->right=deleteNode(root->right,mini->key,flag);
                return root;
            }
        }
        else if(key > root->key){
            root->right=deleteNode(root->right,key,flag);
            return root;
        }
        else{
            root->left=deleteNode(root->left,key,flag);
            return root;
        }
    }

    // SEARCHING A VALUE
    bool findKey(Node* root,Key key)const{
        Node* temp=root;
        while(temp){
            if(key==temp->key){
                return true;
            }
            else if(key > temp->key){
                temp=temp->right;
            }
            else {
                temp=temp->left;
            }
            
        }
        return false;
    }

    

    //PRE-ORDER TRAVERSAL
    void prePrint(Node* root)const{
        if(root==NULL){
            return;
        }
        cout << "(" << root->key <<":" << root->value << ") ";
        prePrint(root->left);
        prePrint(root->right);
    }

    //IN-ORDEER TRAVERSAL
    void inPrint(Node* root)const{
        if(root==NULL){
            return;
        }
        inPrint(root->left);
        cout << "(" << root->key <<":" << root->value << ") ";
        inPrint(root->right);
    }
    
    //POST-ORDER TRAVERSAL
    void postPrint(Node* root)const{
        if(root==NULL){
            return;
        }
        postPrint(root->left);
        postPrint(root->right);
        cout << "(" << root->key <<":" << root->value << ") ";
    }

    // DEFAULT PRINT
    void defaultPrint(Node* root)const{
        if(root==NULL){
            return;
        }
        cout << " (" << root->key <<":" << root->value;
        defaultPrint(root->left);
        defaultPrint(root->right);
        cout << ")";
    }
    // End your private helper functions here

public:
    /**
     * Constructor
     */
    ListBST() : root(nullptr), node_count(0) {}
    
    /**
     * Destructor
     */
    ~ListBST() {
        // TODO: Implement destructor to free memory
        ListBST<Key, Value>::destructingFunc(root);
        root=NULL;
        node_count=0;
        
    }
    
    /**
     * Insert a key-value pair into the BST
     */
    bool insert(Key key, Value value) override {
        // TODO: Implement insertion logic

        bool isInserted=ListBST<Key,Value>::findKey(root,key);
        
        if(isInserted==false){
            root=ListBST<Key, Value>::buildBST(root,key,value);
            node_count++;
        }
        return isInserted;
         
    }
    
    /**
     * Remove a key-value pair from the BST
     */
    bool remove(Key key) override {
        // TODO: Implement removal logic
        bool isRemoved=false;
        
        root=ListBST<Key, Value>::deleteNode(root,key,isRemoved);
        if(isRemoved){
            node_count--;
        }
        return isRemoved;
    }
    
    /**
     * Find if a key exists in the BST
     */
    bool find(Key key) const override {
        // TODO: Implement find logic
         bool ans=ListBST<Key, Value>::findKey(root,key);
         return ans;
    }

    /**
     * Find a value associated with a given key
     */
    Value get(Key key) const override {
        // TODO: Implement get logic

        try{
            Value val=ListBST<Key, Value>::getValue(root,key);
            return val;
        }
        catch(exception &e){
            throw runtime_error("Value not found");
        }
        
        
    }

    /**
     * Update the value associated with a given key
     */
    void update(Key key, Value value) override {
        // TODO: Implement update logic
        Node* temp=root;
         
        while(temp){
            if(temp->key==key){
                temp->value=value;
                 
                break;
            }
            else if(key > temp->key){
                temp=temp->right;
            }
            else{
                temp=temp->left;
            }
        }
    }

    /**
     * Clear all elements from the BST
     */
    void clear() override {
        // TODO: Implement clear logic
        ListBST<Key, Value>::destructingFunc(root);
        root=NULL;
        node_count=0;
    }
    
    /**
     * Get the number of keys in the BST
     */
    size_t size() const override {
        // TODO: Implement size logic
        return node_count;
    }
    
    /**
     * Check if the BST is empty
     */
    bool empty() const override {
        // TODO: Implement empty check logic
        if(node_count==0){
            return true;
        }
        return false;
    }
    
    /**
     * Find the minimum key in the BST
     */
    Key find_min() const override {
        // TODO: Implement find_min logic
        if(root==NULL){
            throw runtime_error("Current BST is empty");
        }
        else{
            Node* mini= ListBST<Key, Value>::Minimum(root);
            return mini->key;
        }
    }
    
    /**
     * Find the maximum key in the BST
     */
    Key find_max() const override {
        // TODO: Implement find_max logic
        if(root==NULL){
            throw runtime_error("Current BST is empty");
        }
        Node* temp=root;
        while(temp->right){
            temp=temp->right;
        }
        return temp->key;
    }

    /**
     * Print the BST using specified traversal method
     */
    void print(char traversal_type = 'D') const override {
        // TODO: Implement print logic
        
        if(traversal_type=='i'){
            cout << "BST (In-order): ";
            ListBST<Key, Value>::inPrint(root);
        }
        else if(traversal_type=='p'){
            cout << "BST (Pre-order): ";
            ListBST<Key, Value>::prePrint(root);
        }
        else if(traversal_type=='o'){
            cout << "BST (Post-order): ";
            ListBST<Key, Value>::postPrint(root);
        }
        else{
            cout << "BST (Default):";
            ListBST<Key, Value>::defaultPrint(root);
        }
        cout << endl;
    }
    
};

#endif // LISTBST_H