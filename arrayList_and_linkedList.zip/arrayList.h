#include <stdio.h>
#include <stdlib.h>

typedef struct 
{
    int *array;
    // declare variables you need

    int total;
    int curr;
    int maxCapacity;
} arrayList;

void init(arrayList* list)
{
    // implement initialization

    list->array=(int*)malloc(2*sizeof(int));
    if(list->array==NULL){
        printf("momory allocation failed");
        exit(0);
    }
    list->total=0;
    list->curr=0;
    list->maxCapacity=2;

}

void free_list(arrayList* list)
{
    // implement destruction of list

    free(list->array);
}

void increase_capacity(arrayList* list)
{
    // implement capacity increase
    

    if(list->total+1 > list->maxCapacity/2){
        list->maxCapacity=list->maxCapacity*2;
        int temp_arr[list->total];
        for(int i=0;i<list->total;i++){
            temp_arr[i]=list->array[i];
        }

        list->array=(int*)realloc(list->array,list->maxCapacity*sizeof(int));
        for(int i=0;i<list->total;i++){
            list->array[i]=temp_arr[i];
        }
        
        printf("Capacity increased from %d to %d\n",(list->maxCapacity)/2,list->maxCapacity);
    }
    

}

void decrease_capacity(arrayList* list)
{
    // implement capacity decrease

    if(list->total-1 < list->maxCapacity/4){
        list->maxCapacity=list->maxCapacity/2;
        int temp_array[list->total];
        for(int i=0;i<list->total;i++){
            temp_array[i]=list->array[i];
        }

        list->array=(int*)realloc(list->array,list->maxCapacity*sizeof(int));
        for(int i=0;i<list->total;i++){
            list->array[i]=temp_array[i];
        }
    printf("Capacity decreased from %d to %d\n",(list->maxCapacity)*2,list->maxCapacity);
    }

}

void print(arrayList* list)
{
    // implement list printing

    
    printf("[ ");

    if(list->total==0){
        printf(".");
    }
    else{
        for(int i=0;i<list->total;i++){
            if(i==list->curr-1){
                 printf("%d| ",list->array[i]);
            }
            else{
                printf("%d ",list->array[i]);
            }
        }
    }
    printf("]\n");
}

void insert(int item, arrayList* list)
{
    // implement insert function
    increase_capacity(list);

    int i=list->total;
    for(;i>list->curr;i--){
        list->array[i]=list->array[i-1];
    }
    list->array[i]=item;
    list->total++;
    list->curr++;
    print(list);
}

int delete_cur(arrayList* list)
{
    // implement deletion of current index function
    if(list->curr==0 && list->total==0)return 0;
    decrease_capacity(list);
    int val=list->array[list->curr-1];
    int flag=0;
    int i=list->curr-1;
    while(i<list->total-1){
         list->array[i]=list->array[i+1];
         i++;
         flag=1;
    }
    list->total--;
    if(!flag)list->curr--;
    print(list);
    return val;
}

void append(int item, arrayList* list)
{
    // implement append function
    if(list->curr==0){
        list->curr++;
    }

    increase_capacity(list);

    list->array[list->total]=item;
    list->total++;
    print(list);
}

int size(arrayList* list)
{
    // implement size function

    return list->total;

}

void prev(int n, arrayList* list)
{
    // implement prev function

    while(n--){
        list->curr--;
    }
    if(list->curr < 1){
        list->curr=1;
    }
    print(list);
}

void next(int n, arrayList* list)
{
    // implement next function

    while(n--){
        list->curr++;
    }
    if(list->curr > list->total){
        list->curr=list->total;
    }
    print(list);
}

int is_present(int n, arrayList* list)
{
    // implement presence checking function
    

    for(int i=0;i<list->total;i++){
        if(list->array[i]==n){
            
            return 1;
        }
    }
    
    return 0;
}

void clear(arrayList* list)
{
    // implement list clearing function
    free_list(list);
    init(list);
    
    print(list);
}

void delete_item(int item, arrayList* list)
{
    // implement item deletion function
    

    int flag=0;
    int i;
    for( i=0;i<list->total;i++){

        if(list->array[i]==item){
            flag=1;
            break;
        }
    }
    if(flag){
        decrease_capacity(list);
        int j=i+1;
        while(j<list->total){
            list->array[j-1]=list->array[j];
            j++;
        }
        if(list->total==list->curr && i<list->curr){
            
            list->curr--;
        }
        
        list->total--;
        print(list);
    }
    else printf("%d not found\n",item);
   
}

void swap_ind(int ind1, int ind2, arrayList* list)
{
    // implement swap function

    if((ind1>=0 && ind1<list->total) && (ind2 >=0 && ind2<list->total)){
        int temp=list->array[ind1];
        list->array[ind1]=list->array[ind2];
        list->array[ind2]=temp;
    }
    print(list);
}

// you can define helper functions you need
