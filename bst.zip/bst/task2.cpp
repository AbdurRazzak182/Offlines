#include <iostream>
#include <fstream>
#include <string>
#include "listBST.hpp"
using namespace std;

int main(int argc, char **argv) {
    if (argc != 2) {
        cerr << "Usage: filename" << "\n";
        return 1;
    }
    ifstream in_file(argv[1]);
    if (!in_file) {
        cerr << "Unable to open file\n";
        return 1;
    }

    BST<string, int> *bst1 = new ListBST<string, int>();
    if (!bst1) {
        cerr << "Memory allocation failed\n";
        return 2;
    }
    BST<string, int> *bst2 = new ListBST<string, int>();
    if (!bst2) {
        cerr << "Memory allocation failed\n";
        delete bst1; // Clean up previously allocated memory
        return 3;
    }

    int n;
    in_file >> n;
    for (int i = 0; i < n; ++i) {
        // TODO: Implement the logic to read Phil's words
        // Start your code here

        string word;
        in_file >> word;
        bool isPresent=bst1->find(word);
        if(isPresent){
            bst1->update(word,bst1->get(word)+1);
        }
        else{
            bst1->insert(word,1);
        }
        // End your code here
    }
    for (int i = 0; i < n; ++i) {
        // TODO: Implement the logic to read Claire's words
        // Start your code here

        string word;
        in_file >> word;
        bool isPresent=bst2->find(word);
        if(isPresent){
            bst2->update(word,bst2->get(word)+1);
        }
        else{
            bst2->insert(word,1);
        }

        // End your code here
    }

    // TODO: Implement the logic to print the initial state of both hands
    // Start your code here

    cout << "Phil's words:" << endl;
    bst1->print('i');
    cout << endl;
    cout << "Claire's words:" << endl;
    bst2->print('i');
    cout << endl;

    // End your code here
    cout << "\nGame starts!\n\n";
    cout << "==============================\n";

    while (true) {
        string word;
        in_file >> word;
        
        // TODO: Implement the logic to process the game turn and print both hands after each turn
        // Start your code here

        bool findInPhil=bst1->find(word);
        bool findInClaire=bst2->find(word);

        if(findInPhil){
            cout << "Phil has " << word << "!" << endl;
            int val=bst1->get(word);
            if(val==1){
                bst1->remove(word);
            }
            else{
                bst1->update(word,val-1);
            }
        }

        if(findInClaire){
            cout << "Claire has " << word << "!" << endl;
            int val=bst2->get(word);
            if(val==1){
                bst1->remove(word);
            }
            else{
                bst2->update(word,val-1);
            }
        }

        cout << endl;

        bool phil=bst1->empty();
        bool claire=bst2->empty();
        if(phil and claire){
            cout << "Tie" <<  endl;
            break;
        }
        else if(phil){
            cout << "Phil Wins" << endl;
            break;
        }
        else if(claire){
            cout << "Claire Wins" << endl;
            break;
        }
        else{
            cout << "Phil's remaining words:" << endl;
            bst1->print('i');
            cout << endl;
            cout << "Claire's remaining words:" << endl;
            bst2->print('i');
            cout << endl;
        }

        // End your code here
        cout << "==============================\n";
        
    }

    in_file.close();
    delete bst1;
    delete bst2;
    return 0;
}