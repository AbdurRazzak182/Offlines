#include <bits/stdc++.h>
using namespace std;


class Course{
    string name;
    float creditHour;
    public:
    Course(){
        name="\0";
        creditHour=0.0;
    }
    Course(string name,float creditHour){
        this->name=name;
        this->creditHour=creditHour;
    }
    void setName(string name){
        this->name=name;

    }
    string getName(){
        return name;
    }
    void setCreditHour(float creditHour){
        this->creditHour=creditHour;
    }
    float getCreditHour(){
        return creditHour;
    }
    void display(){
        cout << "Course name: " << name << "," << 
        "Credit hour: " << creditHour << endl;
    }
};

class Student{
     string name;
     int id;
     Course *courses;
     int totalCourses;
     int maxCourses;
     float* gradePoints;
     public:
     Student(){
        // name="\0";
        // id=000;
        // courses=new Course[1];
        // totalCourses=0;
        // maxCourses=0;
        // gradePoints=new float[1];
     }
     Student(string name,int id,int maxCourses){
         this->name=name;
         this->id=id;
         this->maxCourses=maxCourses;
         totalCourses=0;
         courses=new Course[maxCourses];
         gradePoints=new float[maxCourses];
     }
     Student(const Student& std){
          name=std.name;
          id=std.id;
          maxCourses=std.maxCourses;
          totalCourses=std.totalCourses;
          
          courses=new Course[maxCourses];
          for(int i=0;i<totalCourses;i++){
              courses[i]=std.courses[i];
          }
          gradePoints=new float[maxCourses];
          for(int i=0;i<totalCourses;i++){
                gradePoints[i]=std.gradePoints[i];
          }
     }
      

     

     void setName(string name){
        this->name=name;
     }
     void setId(int id){
        this->id=id;
     }
     void setInfo(string name,int id){
         this->name=name;
         this->id=id;
     }
     void addCourse(Course c){
          if(totalCourses >= maxCourses){
              cout << "cannot add more courses to " << name << endl;
              cout << "=================================" << endl;
              return;
          }
          courses[totalCourses]=c;
          gradePoints[totalCourses]=0.0;
          totalCourses++;
     }

     void addCourse(Course course,float gradePoint){
        if(totalCourses >= maxCourses){
            cout << "cannot add more courses to " << name  << endl;
            cout << "=====================================" << endl;
            return;
        }
        courses[totalCourses]=course;
        gradePoints[totalCourses]=gradePoint;
        totalCourses++;
     }

     void setGradePoint(Course c,float gradePoint){
         int i=0;
         while(i<totalCourses){
            if(courses[i].getName()==c.getName()){
                break;
            }
            i++;
         }
         if(i<totalCourses){
            gradePoints[i]=gradePoint;
         }
     }

     void setGradePoint(float *gradePoints,int n){
        
        for(int i=0;i<n;i++){
            if(i>=totalCourses){
                cout << "out of bound" << endl;
                break;
            }
            this->gradePoints[i]=gradePoints[i];
        }

     }
     string getName(){
        return name;
     }
     float getCGPA(){
        float sumCredit=0.0;
        float sumCreditGpa=0.0;
        for(int i=0;i<totalCourses;i++){
            sumCreditGpa+=courses[i].getCreditHour()*gradePoints[i];
            sumCredit+=courses[i].getCreditHour();
        }
        return sumCreditGpa/sumCredit;
     }

     float getGradePoint(Course c){
        
        for(int i=0;i<totalCourses;i++){
            if(courses[i].getName()==c.getName()){
                return gradePoints[i];
            }
        }
        return 0.0;
        
     }

     int getTotalCourses(){
        return totalCourses;
     }

     float getTotalCreditHours(){
        float sumCredit=0.0;
        for(int i=0;i<totalCourses;i++){
            if(gradePoints[i] >=2.0 ){
                sumCredit+=courses[i].getCreditHour();
            }
        }
        return sumCredit;
     }

     Course getMostFavoriteCourse(){
        float Max=-10.00;
        Course temp;
        for(int i=0;i<totalCourses;i++){
            if(gradePoints[i]>Max){
                 Max=gradePoints[i];
                 temp=courses[i];
            }
        }
        return temp;
     }

     Course  getLeastFavoriteCourse() {
        float Min=10.00;
        Course temp;
        for(int i=0;i<totalCourses;i++){
            if(gradePoints[i]<Min){
                 Min=gradePoints[i];
                 temp=courses[i];
            }
        }
        return temp;
     }
     
     Course*  getFailedCourses(int  &count){
        Course* list=new Course[totalCourses];
        int cnt=0;
        for(int i=0;i<totalCourses;i++){
            if(gradePoints[i]<2.0){
                list[cnt++]=courses[i];
            }
        }
        count=cnt;
        return list;
     }

     void display(){
        cout << "Student Name: " << name << "," << " ID: " << id << endl;
        for(int i=0;i<totalCourses;i++){
            cout << "Course Name: " << courses[i].getName() << ", Credit Hour: "<<
            courses[i].getCreditHour() << ", gradePoint: " << gradePoints[i] << endl;
        }
        cout << "CGPA: " << getCGPA() << endl;
        cout << "Total Credit Hours Earned: " << getTotalCreditHours() << endl;
        cout << "Most Favorite Course: " << getMostFavoriteCourse().getName() << endl;
        cout << "Least Favorite Course: " << getLeastFavoriteCourse().getName() << endl;
        cout << "====================================" << endl;
     }

     ~Student(){
          delete[] courses;
          delete[] gradePoints;
          
     }


};

Student *students[100];
int totalStudents;

Student getTopper(){
    float Max=-10.0;
    Student *temp;
    for(int i=0;i<totalStudents;i++){
        float grade=students[i]->getCGPA();
        if(grade>Max){
            Max=grade;
            temp=students[i];
        }
    }
    return *temp;
}

Student getTopper(Course c){
    float Max=-10.00;
    Student *temp;
    for(int i=0;i<totalStudents;i++){
        float grade=students[i]->getGradePoint(c);
        
        if(grade > Max){
            Max=grade;
            
            temp=students[i];
        
        }
    }
    
    return *temp;
}

int main(){
    
        // generate courses 
        const int COURSE_COUNT = 6; 
        Course courses[COURSE_COUNT] = { 
        Course("CSE107", 3), 
        Course("CSE105", 3), 
        Course("CSE108", 1.5), 
        Course("CSE106", 1.5), 
        Course("EEE164", 0.75), 
        Course("ME174", 0.75), 
        }; 
        float gradePoints[COURSE_COUNT] = {4.0, 4.0, 3.5, 3.5, 4.0, 3.25}; 
        // generate students 
        Student s1 = Student("Sheldon", 1, 5); 
        students[totalStudents++] = &s1; 
        // add courses to s1 
        s1.addCourse(courses[0]); 
        s1.addCourse(courses[1]); 
        s1.addCourse(courses[2]); 
        s1.addCourse(courses[3]); 
        s1.addCourse(courses[4]); 
        s1.addCourse(courses[5]); 
        s1. setGradePoint (gradePoints, s1.getTotalCourses()); 
        s1.display(); 
        Student s2 = Student("Penny", 2, 5); 
        students[totalStudents++] = &s2; 
        s2.addCourse(courses[0]); 
        s2.addCourse(courses[2]); 
        s2.addCourse(courses[5]); 
        s2. setGradePoint (gradePoints, s2.getTotalCourses()); 
        s2. setGradePoint (courses[0], 3.25); 
        s2.display(); 
        
        Student s3 = s2; 
        
        students[totalStudents++] = &s3; 
        s3.setName("Leonard"); 
        s3.setId(3); 
        s3. setGradePoint (gradePoints, s3.getTotalCourses()); 
        s3.addCourse(courses[1], 3.75); 
        s3.display(); 
        Student s4 = s3; 
        students[totalStudents++] = &s4; 
        s4.setInfo("Howard", 4); 
        s4. setGradePoint (gradePoints, s4.getTotalCourses()); 
        s4.addCourse(courses[3], 3.75); 
        s4.display(); 
        Student s5 = s4; 
        students[totalStudents++] = &s5; 
        s5.setInfo("Raj", 5); 
        s5. setGradePoint (gradePoints, s5.getTotalCourses()); 
        s5. setGradePoint (courses[0], 1.5); 
        s5. setGradePoint (courses[2], 2.0); 
        s5. setGradePoint (courses[5], 1.75); 
        s5. setGradePoint (courses[3], 3.75); 
        s5.display(); 
        int failedCount; 
        Course* failedCourses = s5.getFailedCourses(failedCount); 
        cout << "Failed Courses for " << s5.getName() << ":" << endl; 
        for (int i = 0; i < failedCount; ++i) { 
        failedCourses[i].display(); 
        cout << endl; 
    } 
        delete[] failedCourses; 

        cout << "==================================" << endl; 
        Student topper = getTopper(); 
        cout << "Topper: " << topper.getName() << endl; 
        cout << "Topper CGPA: " << topper.getCGPA() << endl; 
        cout << "==================================" << endl; 
        for (int i = 0; i < COURSE_COUNT; ++i) { 
        Course c = courses[i]; 
        Student topperInCourse = getTopper(c); 
        cout << "Topper in " << c.getName() << ": " << 
        topperInCourse.getName() << endl; 
        cout << "Topper in " << c.getName() << " gradePoint: " << 
        topperInCourse.getGradePoint(c) << endl; 
        cout << "==================================" << endl; 
    }
        return 0;

}