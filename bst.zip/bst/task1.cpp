#include <iostream>
#include <fstream>
#include "listBST.hpp"

using namespace std;

int main(int argc, char **argv) {
    if (argc != 2) {
        cerr << "Usage: filename" << "\n";
        return 1;
    }
    ifstream in_file(argv[1]);
    if (!in_file) {
        cerr << "Unable to open file\n";
        return 2;
    }
    char c, str[5];
    int val;
    BST<int, int> *bst = new ListBST<int, int>();
    if (!bst) {
        cerr << "Memory allocation failed\n";
        return 3;
    }
    while (in_file >> c) {
        // TODO: Implement the logic to read commands from the file and output accordingly
        // After every insertion and removal, print the BST in nested parentheses format
        // Handle exceptions where necessary and print appropriate error messages

        // Start your code here

        if(c=='I'){
            int val;
            in_file >> val;
            bool flag=bst->insert(val,val);
            if(flag==false){
                cout << "Key " << val << " inserted into BST, ";
            }
            else{
                cout << "Insertion failed! Key " << val << " already exists in BST,";
            }
            bst->print();
        }
        else if(c=='F'){
            int val;
            in_file >> val;
            cout << "Key " << val << " ";
            if(bst->find(val)==false)cout << "not ";
            cout << "found in BST" << endl;
        }
        else if(c=='E'){
            if(bst->empty())cout << "Empty" << endl;
            else cout << "Not empty" << endl;
        }
        else if(c=='M'){
            string word;
            in_file >> word;
            if(word=="Min"){
                try{
                    cout << "Minimum value: ";
                    cout << bst->find_min() << endl;
                }
                catch(exception& e){
                    cout << e.what() << endl;
                }
            }
            else{
                try{
                    cout << "Maximum value: ";
                    cout << bst->find_max() << endl;
                }
                catch(exception& e){
                    cout << e.what() << endl;
                }
            }
        }
        else if(c=='D'){
            int val;
            in_file >> val;
            bool flag=bst->remove(val);
            if(flag){
                cout << "Key " << val << " removed from BST, ";
                bst->print();
            }
            else{
                cout << "Key not found" << endl;
            }
        }
        else if(c=='S'){
             cout << "Size: " <<  bst->size() << endl;
        }
        else{
            string word;
            in_file >> word;
            if(word=="In"){
                bst->print('i');
            }
            else if(word=="Pre"){
                bst->print('p');
            }
            else {
                bst->print('o');
            }
        }

        // End your code here
    }
    in_file.close();
    delete bst;
    return 0;
}
