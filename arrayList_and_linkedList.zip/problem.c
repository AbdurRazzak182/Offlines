#include <stdio.h>
 #include "arrayList.h"
// #include "linkedList.h"


int main()
{
    FILE* file = fopen("in_prob.txt", "r");
    if(file == NULL){
        return 1;
    }

    arrayList dal, fl;
    // linkedList dal, fl;
    
    // initialize the lists

    init(&dal);
    init(&fl);

    

    int func, param;
    while(fscanf(file, "%d", &func) == 1 && func != 0)
    {
        if(func == 1 && fscanf(file, "%d", &param) == 1){
            printf("Recruit %d\n", param);
            // implement logic here
            
            int flag=is_present(param,&fl);
            
            if(flag==0){
                printf("DA list:\n");
                 append(param,&dal);
            }
            else{
                 printf("In the Foe list,cannot recruit\n");
            }

        }
        else if(func == 2 && fscanf(file, "%d", &param) == 1){
            printf("Fire %d\n", param);
            // implement logic here

            int flag=is_present(param,&dal);
            if(flag){
                printf("DA list:\n");
                delete_item(param,&dal);
                printf("Foe list:\n");
                append(param,&fl);
            }
            else{
                printf("Not present in the DA list,cannot fire\n");
            }
        }
        else if(func == 3 && fscanf(file, "%d", &param) == 1){
            printf("Check %d\n", param);
            //implement logic here

            int flag1=is_present(param,&dal);
            if(flag1){
                printf("Friend\n");
            }
            else{
                int flag2=is_present(param,&fl);
                if(flag2){
                    printf("Foe\n");
                }
                else {
                    printf("Unknown\n");
                }
            }
        }
        else{
            break;
        }
        printf("\n");
    }
   
    // free memory
    
    return 0;
}