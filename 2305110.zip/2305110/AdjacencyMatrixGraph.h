#ifndef ADJACENCY_MATRIX_GRAPH_H
#define ADJACENCY_MATRIX_GRAPH_H

#include "GraphADT.h"
#include "queue.h"
#include "YourListType.h"


class AdjacencyMatrixGraph : public GraphADT
{
private:
    //TODO: Consider necessary private members as per your discretion
    int **arr;
    
    int size;
    int maxSize;
    bool *nodeTrack;
    


    void resizeMatrix()
    {
        //TODO: you need to resize your matrix when you will less data or more data
        int newMaxSize=maxSize*2;
        int** new_arr=new int*[newMaxSize];
        
        for(int i=0;i<newMaxSize;i++){
            new_arr[i]=new int[newMaxSize];
            for(int j=0;j<newMaxSize;j++){
                if(j< maxSize and i<maxSize){
                    new_arr[i][j]=arr[i][j];
                }
                else{
                    new_arr[i][j]=0;
                }
            }
        }
        for(int i=0;i<maxSize;i++){
            delete[] arr[i];
        }
        delete[] arr;
        arr=new_arr;

        bool* temp=new bool[newMaxSize];
        for(int i=0;i<newMaxSize;i++){
            temp[i]=false;
            if(i<maxSize)
            temp[i]=nodeTrack[i];
        }
        delete []nodeTrack;
        nodeTrack=temp;
        maxSize=newMaxSize;
    }

    //PRIVATE HELPER METHOD


    // void init(){
    //     // arr=new int*[2];
    //     // arr[0]=new int[1];
    //     // size=0;
    //     // nodeTrack=new bool[1];
    //     // maxSize=1;
    //     arr=new int*[2];
    //     for(int i=0;i<2;i++){
    //         arr[i]=new int[2]();
    //         for(int j=0;j<2;j++){
    //             arr[i][j]=0;
    //         }
    //     }
    //     maxSize=2;
    //     size=0;
    //     nodeTrack=new bool[maxSize]();
    //     for(int i=0;i<maxSize;i++){
    //         nodeTrack[i]=false;
    //     }
    // }

    

public:


    AdjacencyMatrixGraph(){
        
        
        maxSize=4;
        size=0;
        arr=new int*[maxSize];
        for(int i=0;i<maxSize;i++){
            arr[i]=new int[maxSize];
            for(int j=0;j<maxSize;j++){
                arr[i][j]=0;
            }
        }
        nodeTrack=new bool[maxSize];
        for(int i=0;i<maxSize;i++){
            nodeTrack[i]=false;
        }
    }

    ~AdjacencyMatrixGraph() {
        if(arr){
            for(int i = 0;i<maxSize;i++) {
                delete[] arr[i];
            }
            delete[] arr;
        }
        delete[] nodeTrack;
    }
    void AddNode(int v) override
    {
        //TODO: Add a new node v and resize the matrix if your current matrix is almost going to be full.

        if(v  <0){
            cout << "Invalid" << endl;
            return;
        }
        
        
       while(v >= maxSize){
          resizeMatrix();
          
       }
       
       if(!nodeTrack[v])
       {
          size++;
          nodeTrack[v]=true;
    }

       
    }

    void AddEdge(int u, int v) override
    {
        //TODO: Add a new edge between the nodes u and v

        if(u < 0 || v < 0){
            cout << "Invalid " << endl;
            return;
        }
        
        if(!nodeTrack[u]){
            AddNode(u);
        }
        if(!nodeTrack[v]){
            AddNode(v);
        }
        arr[u][v]=1;
        arr[v][u]=1;
    }

    bool CheckEdge(int u, int v) const override
    {
        //TODO: Check whether there is an edge between two nodes u and v



        if( u >=0 and v >= 0 and u < maxSize and v < maxSize and nodeTrack[u] and nodeTrack[v]){
            if(arr[u][v]==1){
                return true;
            }  
        }

        return false;
    }

    void RemoveNode(int v) override
    {
        //TODO: Remove a node.
        if(v <0 || v >=maxSize || !nodeTrack[v]){
            return;
        }
        
        for(int i=0;i<maxSize;i++){
             if(nodeTrack[i]){
                arr[i][v]=0;
                arr[v][i]=0;
             }
         }
        nodeTrack[v]=false;
        size--;
        
    }

    void RemoveEdge(int u, int v) override
    {
        //TODO: remove an edge

        if(u<0 || v <0 || u >= maxSize || v >=maxSize || !nodeTrack[u] || !nodeTrack[v]){
            return;
        }
        
        arr[u][v]=0;
        arr[v][u]=0;
        
    }

    bool CheckPath(int u, int v) const override
    {
        //TODO: Return true if there is a path between nodes u and v. Otherwise return false

        if(u < 0 || v < 0 || !nodeTrack[u] || !nodeTrack[v] || u>=maxSize || v>=maxSize){
            return false;
        }
        ListQueue q;
        q.enqueue(u);
        bool *visited=new bool[maxSize];
        for(int i=0;i<maxSize;i++){
            visited[i]=false;
        }
        visited[u]=true;
        while(!q.empty()){
            int front=q.dequeue();
            if(front==v)return true;
            for(int i=0;i<=maxSize;i++){
                if(!visited[i] and arr[front][i]==1 and nodeTrack[i]){
                    visited[i]=true;
                    q.enqueue(i);
                }
            }
        }
        delete[] visited;
        
        return false;
    }

    void FindShortestPath(int u, int v) const override
    {
        //TODO: Find the shortest path between the nodes u and v and print it.

        if(u < 0 || v <0 ||  u >= maxSize || v >= maxSize || !nodeTrack[u] || !nodeTrack[v]){
            cout << "Given two nodes are not present in current graph" << endl;
            return;
        }

        bool *visited=new bool[maxSize];
        for(int i=0;i<maxSize;i++){
            visited[i]=false;
        }
        int *parent=new int[maxSize];
        for(int i=0;i<maxSize;i++){
            parent[i]=-1;
        }
        int *ans=new int[maxSize];
        int ans_count=0;
        ListQueue q;
        q.enqueue(u);
        visited[u]=true;
        while(!q.empty()){
            int front=q.dequeue();
            for(int i=0;i<maxSize;i++){
                if(arr[front][i]==1 and !visited[i] and nodeTrack[i]){
                    visited[i]=true;
                    q.enqueue(i);
                    parent[i]=front;
                }
            }
        }
        if(!visited[v]){
            delete[] visited;
            delete[] ans;
            delete[] parent;
            cout << "Not reachable" << endl;
            return;
        }
        ans[ans_count++]=v;
        while(parent[v]!=-1){
            ans[ans_count++]=parent[v];
            v=parent[v];
        }
        for(int i=ans_count-1;i>=0;i--){
            cout << ans[i] << " ";
        }
        cout << endl;
        delete[] visited;
        delete[] ans;
        delete[] parent;

    }

    int FindShortestPathLength(int u, int v) const override
    {
        //TODO: Return the shortest path length between nodes u and v if any such path exists. Otherwise return -1.

        if(u< 0 || v < 0 || u >= maxSize || v >= maxSize || !nodeTrack[u] || !nodeTrack[v]){
            cout << "Given two nodes are not present in current graph" << endl;
            return -1;
        }

        bool *visited=new bool[maxSize];
        for(int i=0;i<maxSize;i++){
            visited[i]=false;
        }
        int *parent=new int[maxSize];
        for(int i=0;i<maxSize;i++){
            parent[i]=-1;
        }
        
        
        ListQueue q;
        q.enqueue(u);
        visited[u]=true;
        while(!q.empty()){
            int front=q.dequeue();
            for(int i=0;i<maxSize;i++){
                if(arr[front][i]==1 and !visited[i] and nodeTrack[i]){
                    visited[i]=true;
                    q.enqueue(i);
                    parent[i]=front;
                }
            }
        }
        if(!visited[v]){
            delete[] visited;
            delete[] parent;
            cout << "Not reachable" << endl;
            return -1;
        }

        int ans_count=0;
        while(parent[v]!=-1){
           ans_count++;
           v=parent[v];
        }
        delete[] visited;
        delete[] parent;
        return ans_count;
    }
    YourListType GetNeighbors(int u) const override
    {
        //TODO return a list of neighbors of node u
        
        YourListType list(4);
        if(u < 0 || u >=maxSize || nodeTrack[u]==false){
            return list;
        }
       for(int i=0;i<maxSize;i++){
          if(arr[u][i]==1 and nodeTrack[i]){
             list.add(i);
          }
       }
        return list;


    }

};

#endif // ADJACENCY_MATRIX_GRAPH_H
