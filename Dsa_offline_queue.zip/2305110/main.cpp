#include <iostream>
#include <vector>
#include "queue.h"
using namespace std;

/********************************* RANDOM ************************************/
#define LCG_MULTIPLIER (1103515245)
#define LCG_INCREMENT (12345)
#define LCG_MODULUS ((unsigned)~0 >> 1)
static unsigned int lcg_seed = 1;
void custom_srand(unsigned int seed)
{
    lcg_seed = seed;
}
int custom_rand()
{
    lcg_seed = (LCG_MULTIPLIER * lcg_seed + LCG_INCREMENT) % (LCG_MODULUS + 1);
    return lcg_seed;
}
int randomQueue(int seed = -1)
{
    static bool initialized = false;
    if (seed != -1 && !initialized)
    {
        custom_srand(seed);
        initialized = true;
        return -1;
    }
    cout << "randomQueue() called" << endl;
    return (custom_rand() % 2) + 1;
}
/*****************************************************************************/

int main()
{
    // freopen("test_input_1.txt", "r", stdin); // Test Case 1
    freopen("test_input_2.txt", "r", stdin); // Test Case 2
    freopen("output.txt", "w", stdout);
    // Initialize the random generator with a fixed seed
    // You should set the seed only once at the beginning of your program
    // NOTE: Do not modify the following lines.
    randomQueue(42);

    Queue *Q1 = new ListQueue();
    Queue *Q2 = new ListQueue();
    Queue *Q = new ArrayQueue();

    int N;
    cin >> N;
    int arr[10001];
    bool open=true;

    for (int i = 1; i <= N; i++)
    {
        // TODO: Edit here to add your own logic
        

        int key;
        cin >> key;
        if(key==1){
            
            int id,ts;
            cin >> id >> ts;
            cout << "Operation " << i << " (Arrival " << id << " " << ts << "): ";
            arr[id]=ts;
            bool flag=true;
            if(open){
                 if(Q1->empty() and Q2->empty()){
                      int val=randomQueue();
                      flag=false;
                      if(val==1){
                        Q1->enqueue(id);
                      }
                      else{
                        Q2->enqueue(id);
                      }
                 }
                 else if(Q1->empty()){
                     Q1->enqueue(id);
                     
                 }
                 else if(Q2->empty()){
                     Q2->enqueue(id);
                     
                 }
                 else{
                    int ts1=arr[Q1->back()];
                    int ts2=arr[Q2->back()];
                    if(ts1 < ts2){
                        Q1->enqueue(id);
                    }
                    else{
                        Q2->enqueue(id);
                    }
                    
                 }
            }
            else{
                Q->enqueue(id);
            }
            if(flag)cout << endl;
            cout << "Q1: <" << Q1->toString() << endl;
            cout << "Q2: <" << Q2->toString() << endl;
            cout << "Q : <" << Q->toString() << endl; 
        }
        else if(key==2){
             int id,ts;
             cin >> id >> ts;
             arr[id]=ts;
             cout << "Operation " << i << " (Leave " << id << " " << ts << "): " << endl;
             if(open){
                  bool flag=true;
                  int size1=Q1->size();
                  while(size1--){
                      int val=Q1->dequeue();
                      if(val==id){
                          flag=false;
                      }
                      else{
                         Q1->enqueue(val);
                      }
                  }
                  if(flag){
                     int size2=Q2->size();
                     while(size2--){
                        int val=Q2->dequeue();
                        if(val!=id){
                            Q2->enqueue(val);
                        }
                     }
                  }
                  
                 
             }
             else{
                 int size=Q->size();
                 while(size--){
                    int val=Q->dequeue();
                    if(val!=id){
                        Q->enqueue(val);
                    }
                 }
                 
             }
            cout << "Q1: <" << Q1->toString() << endl;
            cout << "Q2: <" << Q2->toString() << endl;
            cout << "Q : <" << Q->toString() << endl; 
        }
        else if(key==3){
             if(open){
                open=false;
                  while(!Q1->empty() and !Q2->empty()){
                      int val1=Q1->front();
                      int val2=Q2->front();
                      if(arr[val1] < arr[val2]){
                          Q1->dequeue();
                          Q->enqueue(val1);
                      }
                      else{
                        Q2->dequeue();
                        Q->enqueue(val2);
                      }
                  }
                  while(!Q1->empty()){
                     int val=Q1->dequeue();
                     Q->enqueue(val);
                  }
                  while(!Q2->empty()){
                    int val=Q2->dequeue();
                    Q->enqueue(val);
                  }
             }
             else{
                cout << "Q1 and Q2 are empty" << endl;
             }
            
            cout << "Operation " << i << " (Merge): " << endl;
            cout << "Q1: <" << Q1->toString() << endl;
            cout << "Q2: <" << Q2->toString() << endl;
            cout << "Q : <" << Q->toString() << endl; 
            
        }
        else if(key==4){
            if(open){
                cout << "Q is empty" << endl;
            }
            
            else{
                int size=Q->size();
                bool flag=true;
                while(size--){
                    int val=Q->dequeue();
                    if(flag){
                        Q1->enqueue(val);
                        flag=false;
                    }
                    else{
                        Q2->enqueue(val);
                        flag=true;
                    }
                }
                
                open=true;
                cout << endl;
                  
            }
            Q->clear();
            cout << "Operation " << i << " (Split): " << endl;
            cout << "Q1: <" << Q1->toString() << endl;
            cout << "Q2: <" << Q2->toString() << endl;
            cout << "Q : <" << Q->toString() << endl;
        }
        else if(key==5){
            cout << "Operation " << i << " (Departure): ";
            bool flag=true;
            if(open){
                 if(Q1->empty()){
                    Q2->dequeue();
                 }
                 else if(Q2->empty()){
                    Q1->dequeue();
                 }
                 else{
                    int val=randomQueue();
                    flag=false;
                    if(val==1){
                        Q1->dequeue();
                    }
                    else{
                        Q2->dequeue();
                    }
                 }
            }
            else{
                Q->dequeue();
            }
            if(flag)cout << endl;
            cout << "Q1: <" << Q1->toString() << endl;
            cout << "Q2: <" << Q2->toString() << endl;
            cout << "Q : <" << Q->toString() << endl;
        }
        
        
        // After each operation, we will check the queue's size and capacity
        // NOTE: Do not modify the following lines.
        int capacity = ((ArrayQueue *)Q)->getCapacity();
        if ((Q->size() < capacity / 4 && capacity > 2))
        {
            cout << "Error: Queue size is less than 25% of its capacity." << endl;
        }
        else if (capacity < 2)
        {
            cout << "Error: Queue capacity is less than 2." << endl;
        }
    }

    return 0;
}