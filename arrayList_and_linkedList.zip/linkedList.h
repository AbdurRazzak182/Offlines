#include <stdio.h>
#include <stdlib.h>
struct node
{
    int element;
    struct node* next;
    struct node* prev;
};

typedef struct 
{
    // declare head, tail, cur and other variables you need
    
    struct node* head;
    struct node* tail;
    struct node* curr;
     

}linkedList;

void init(linkedList* list)
{
    // implement initialization

    list->head=(struct node*)malloc(sizeof(struct node));
    list->head=NULL;
    list->tail=(struct node*)malloc(sizeof(struct node));
    list->tail==NULL;
    list->curr=(struct node*)malloc(sizeof(struct node));
    list->curr=NULL;
}

void free_list(linkedList* list)
{
    // implement destruction of list
     
    
    
    free(list->head);
    free(list->tail);
    free(list->curr);
}

void print(linkedList* list)
{
    // implement list printing

    printf("[");
    if(list->head==NULL){
        printf(".");
    }
    else{
        struct node* temp=list->head;
        while(temp!=list->tail->next){
            if(temp==list->curr){
                printf("%d| ",temp->element);
            }
            else{
                printf("%d ",temp->element);
            }
            temp=temp->next;
        }
        
    }
    printf("]\n");
}

struct node* firstTimeInsertion(int item,linkedList* list){
    struct node* temp=(struct node*)malloc(sizeof(struct node));
    temp->element=item;
    temp->next=NULL;
    temp->prev=NULL;
    list->tail=temp;
    list->curr=temp;
    return temp;
}

struct node* insertAtTail(int item,linkedList* list){
   struct node* temp=(struct node*)malloc(sizeof(struct node));
    temp->element=item;
    temp->next=NULL;
    list->tail->next=temp;
    temp->prev=list->tail;
    list->tail=temp;
    return list->tail;
}

void insert(int item, linkedList* list)
{
    // implement insert function
    if(list->head==NULL){
        list->head=firstTimeInsertion(item,list);
    }
    else if(list->curr==list->tail){
        list->curr=insertAtTail(item, list);

    }
    else {
        struct node* temp=(struct node*)malloc(sizeof(struct node));
        struct node* temp2=list->curr->next;
        temp->element=item;
        temp->next=temp2;
        temp2->prev=temp;
        list->curr->next=temp;
        temp->prev=list->curr;
        list->curr=temp;
    }
    print(list);

    
}

int delete_cur(linkedList* list)
{
    // implement deletion of current index function

    int deleted_val;
    if(list->curr==NULL){
        printf("No deletion, empty list\n");
    }
    else if(list->curr->next==NULL && list->curr->prev==NULL){
        deleted_val=list->curr->element;
        list->head=NULL;
        list->curr=NULL;
        list->tail=NULL;

    }
    else if(list->curr==list->head){
        deleted_val=list->head->element;
        list->head=list->head->next;
        list->head->prev=NULL;
        list->curr->next=NULL;
        list->curr=list->head;
    }
    else if(list->curr==list->tail){
        deleted_val=list->curr->element;
        list->tail=list->tail->prev;
        list->tail->next=NULL;
        list->curr->prev=NULL;
        list->curr=list->tail;
    }
    else{
        deleted_val=list->curr->element;
        struct node* temp=list->curr;
        struct node* previous=list->curr->prev;
        list->curr=list->curr->next;
        previous->next=list->curr;
        list->curr->prev=previous;
        temp->prev=NULL;
        temp->next=NULL;
    }
    print(list);
    return deleted_val;
}

void append(int item, linkedList* list)
{
    // implement append function

    if(list->head==NULL){
        list->head=firstTimeInsertion(item,list);
    }
    else{
        list->tail=insertAtTail(item,list);
    }
    print(list);
    
}

int size(linkedList* list)
{
    // implement size function

    int count=0;
    struct node* temp=list->head;
    while(temp!=list->tail->next){
        count++;
        temp=temp->next;
    }
    return count;
}

void prev(int n, linkedList* list)
{
    // implement prev function

    while(n-- && list->curr!=list->head){
         list->curr=list->curr->prev;
    }
    print(list);
}

void next(int n, linkedList* list)
{
    // implement next function

    while(n-- && list->curr!=list->tail){
        list->curr=list->curr->next;
    }
    print(list);
}

int is_present(int n, linkedList* list)
{
    // implement presence checking function

    if(list->head==NULL){
        return 0;
    }

    struct node* temp=list->head;
    while(temp!=list->tail->next){
        if(temp->element==n){
            return 1;
        }
        temp=temp->next;
    }
    return 0;

}

void clear(linkedList* list)
{
    // implement list clearing function

    free_list(list);
    init(list);
    print(list);
}

void delete_item(int item, linkedList* list)
{
    // implement item deletion function

    struct node* temp=list->head;
    while(temp!=list->tail->next){
        if(temp->element==item)break;
        temp=temp->next;
    }
    if(temp==NULL){
        printf("%d not found\n",item);
    }
    else if(temp==list->curr){
        int deleted_val=delete_cur(list);
    }
    else if(temp==list->tail){
         struct node* previous=temp->prev;
         list->tail=previous;
         list->tail->next=NULL;
         temp->prev=NULL;
         print(list);

    }
    else if(temp==list->head){
        list->head=list->head->next;
        temp->next=NULL;
        list->head->prev=NULL;
        print(list);
    }
    else{
        struct node* previous=temp->prev;
        previous->next=temp->next;
        temp->next->prev=previous;
        temp->next=NULL;
        temp->prev=NULL;
        print(list);
    }


}

void swap_ind(int ind1, int ind2, linkedList* list)
{
    // implement swap function

    struct node* temp1=list->head;
    struct node* temp2=list->head;
    while(ind1-- && temp1!=list->tail->next){
        temp1=temp1->next;
    }
    while(ind2-- && temp2!=list->tail->next){
        temp2=temp2->next;
    }
    if(temp1 && temp2){
        int temp=temp1->element;
        temp1->element=temp2->element;
        temp2->element=temp;
    }
    print(list);
}

// you can define helper functions you need