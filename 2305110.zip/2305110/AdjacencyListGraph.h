#ifndef ADJACENCY_LIST_GRAPH_H
#define ADJACENCY_LIST_GRAPH_H

#include "GraphADT.h"
#include "YourListType.h"
#include "linkedList.h"
#include <iostream>
using namespace std;
#include "queue.h"


class AdjacencyListGraph : public GraphADT
{
private:
    // TODO: Take necessary private members
    linkedList* arr;
    bool* nodeTrack;
    int current;
    int maxSize;


    void resize(){
        int new_maxSize=maxSize*2;
        linkedList* new_arr=new linkedList[new_maxSize];
        for(int i=0;i<new_maxSize;i++){
            init(&new_arr[i]);
            if(i < maxSize){
                new_arr[i]=arr[i];
            }

        }
        delete[] arr;
        
        bool* new_nodeTrack=new bool[new_maxSize];
        for(int i=0;i<new_maxSize;i++){
            new_nodeTrack[i]=false;
            if(i < maxSize){
                new_nodeTrack[i]=nodeTrack[i];
            }
        }
        delete[] nodeTrack;

        arr=new_arr;
        nodeTrack=new_nodeTrack;
        maxSize=new_maxSize;
    }

public:

    AdjacencyListGraph(){
        arr=new linkedList[4];
        for(int i=0;i<4;i++){
            init(&arr[i]);
        }
        nodeTrack=new bool[4];
        for(int i=0;i<4;i++){
            nodeTrack[i]=false;
        }
        current=0;
        maxSize=4;

    }
    ~AdjacencyListGraph(){
        for(int i=0;i<maxSize;i++){
            clear(&arr[i]);
        }
        delete[] arr;
        delete[] nodeTrack;
    }

    void AddNode(int v) override
    {
        //TODO: Add a new node v and resize the matrix if your current matrix is almost going to be full.

        if(v < 0){
            cout << "Invalid" << endl;
            return;
        }
        while(v >=maxSize){
            resize();
        }
        if(!nodeTrack[v]){
            nodeTrack[v]=true;
            current++;
        }

    }

    void AddEdge(int u, int v) override
    {
        //TODO: Add a new edge between the nodes u and v{
        if(u < 0 or v <0){
            cout << "Invalid" << endl;
            return;
        }
        if(!nodeTrack[u]){
            AddNode(u);
        }
        if(!nodeTrack[v]){
            AddNode(v);
        }

        append(u,&arr[v]);
        append(v,&arr[u]);

    }

    bool CheckEdge(int u, int v) const override
    {
        //TODO: Check whether there is an edge between two nodes u and v
        if(u<0 || v <0 || !nodeTrack[u] || !nodeTrack[v] || u >=maxSize || v >=maxSize){
            return false;
        }
        return is_present(u,&arr[v]);

    }

    void RemoveNode(int v) override
    {
        //TODO: Remove a node.

        if(v <0 || v >=maxSize || !nodeTrack[v]){
            return;
        }
        clear(&arr[v]);
        nodeTrack[v]=false;
        current--;
        for(int i=0;i<maxSize;i++){
            if(nodeTrack[i]){
                delete_item(v,&arr[i]);
            }
        }

    }

    void RemoveEdge(int u, int v) override
    {
        //TODO: remove an edge

        if(u<0 || v <0 || u >= maxSize || v >=maxSize || !nodeTrack[u] || !nodeTrack[v]){
            return;
        }
        delete_item(u,&arr[v]);
        delete_item(v,&arr[u]);

    }

    bool CheckPath(int u, int v) const override
    {
                //TODO: Return true if there is a path between nodes u and v. Otherwise return false

                if(u<0 || v <0 || u >= maxSize || v >=maxSize || !nodeTrack[u] || !nodeTrack[v]){
                     return false;
                }
                ListQueue q;
                q.enqueue(u);
                bool* visited=new bool[maxSize];
                for(int i=0;i<maxSize;i++){
                     visited[i]=false;
               }
               visited[u]=true;
               while(!q.empty()){
                    int front=q.dequeue();
                    if(front==v){
                        delete[] visited;
                        return true;
                    }
                    int len=size(&arr[front]);
                    int *node=new int[len];
                    inList(node,&arr[front],len);
                    for(int i=0;i<len;i++){
                        if(!visited[node[i]] and nodeTrack[node[i]]){
                            visited[node[i]]=true;
                            q.enqueue(node[i]);
                        }
                    }
                    delete[] node;
                    
              }
              delete[] visited;
        
        return false;


    }

    void FindShortestPath(int u, int v) const override
    {
                //TODO: Find the shortest path between the nodes u and v and print it.
        if(u<0 || v <0 || u >= maxSize || v >=maxSize || !nodeTrack[u] || !nodeTrack[v]){
                    cout << "Data not found" << endl;
                     return;
                }

        bool *visited=new bool[maxSize];
        for(int i=0;i<maxSize;i++){
            visited[i]=false;
        }
        int *parent=new int[maxSize];
        for(int i=0;i<maxSize;i++){
            parent[i]=-1;
        }
        int *ans=new int[maxSize];
        int ans_count=0;
 
        ListQueue q;
        q.enqueue(u);
        visited[u]=true;
        while(!q.empty()){
            int front=q.dequeue();
            int len=size(&arr[front]);
                    int *node=new int[len];
                    inList(node,&arr[front],len);
                    for(int i=0;i<len;i++){
                        if(!visited[node[i]] and nodeTrack[node[i]]){
                            visited[node[i]]=true;
                            q.enqueue(node[i]);
                            parent[node[i]]=front;
                        }
                    }
                    delete[] node;
        }
        if(!visited[v]){
            cout << "Not reachable" << endl;
            return;
        }
        ans[ans_count++]=v;
        while(parent[v]!=-1){
            ans[ans_count++]=parent[v];
            v=parent[v];
        }
        for(int i=ans_count-1;i>=0;i--){
            cout << ans[i] << " ";
        }
        cout << endl;
        delete[] visited;
        delete[] parent;
        delete[] ans;
    }

    int FindShortestPathLength(int u, int v) const override
    {
                //TODO: Return the shortest path length between nodes u and v if any such path exists. Otherwise return -1.
         if(u<0 || v <0 || u >= maxSize || v >=maxSize || !nodeTrack[u] || !nodeTrack[v]){
            cout << "Data not found" << endl;
                     return -1;
        }

        bool *visited=new bool[maxSize];
        for(int i=0;i<maxSize;i++){
            visited[i]=false;
        }
        int *parent=new int[maxSize];
        for(int i=0;i<maxSize;i++){
            parent[i]=-1;
        }
        int *ans=new int[maxSize];
        
 
        ListQueue q;
        q.enqueue(u);
        visited[u]=true;

         while(!q.empty()){
            int front=q.dequeue();
            int len=size(&arr[front]);
                    int *node=new int[len];
                    inList(node,&arr[front],len);
                    for(int i=0;i<len;i++){
                        if(!visited[node[i]] and nodeTrack[node[i]]){
                            visited[node[i]]=true;
                            q.enqueue(node[i]);
                            parent[node[i]]=front;
                        }
                    }
                    delete[] node;
        }
        if(!visited[v]){
            delete[] visited;
            delete[] parent;
            cout << "Not reachable" << endl;
            return -1;
        }
        int ans_count=0;
        while(parent[v]!=-1){
           ans_count++;
           v=parent[v];
        }
        delete[] visited;
        delete[] parent;
        
        return ans_count;

    }

    YourListType GetNeighbors(int u) const override
    {
                //TODO: Return the list of neighbors.

         YourListType list(4);
        if( u <0 || u >=maxSize || !nodeTrack[u] ){
            return list;
        }
       
                    int len=size(&arr[u]);
                    int *node=new int[len];
                    inList(node,&arr[u],len);
                    for(int i=0;i<len;i++){
                        list.add(node[i]);
                    }
                    delete[] node;
        return list;


    }

    

};

#endif // ADJACENCY_LIST_GRAPH_H
