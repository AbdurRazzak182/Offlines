//YourListType.h
#ifndef YOUR_LIST_TYPE_H
#define YOUR_LIST_TYPE_H
using namespace std;

class YourListType{
    public:
    int* arr;
    int current;
    int maxSize;

    YourListType(int v){
        maxSize=v;
        arr=new int[maxSize];
        current=0;
    }

   

    void resize(){
         int *new_arr=new int[maxSize*2];
         for(int i=0;i<maxSize;i++){
            new_arr[i]=arr[i];
         }
         maxSize*=2;
         delete[] arr;
         arr=new_arr;
    }
    void add(int value){
          if(current >= maxSize){
            resize();
          }
          arr[current++]=value;
    }
    ~YourListType(){
        delete[] arr;
    }
   
    int* begin() { return arr; }
    int* end() { return arr + current; }

    const int* begin() const { return arr; }
    const int* end() const { return arr + current; }

};

#endif 

